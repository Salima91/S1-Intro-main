/**
 * fuunction qui permet de recuperer les recettes en fonction du jour choisi
 * @returns {boolean}
 */
function afficherRecette() {

  // recuperee la valeur du select
    let jourChoisi = document.getElementById("select").value;
  //  console.log(select);
    // chercher cette valeur dans le tableau des recettes dans mock api
    //recuperernd'abord les recettes
    fetch('https://6427c806161067a83b00e7a8.mockapi.io/Recettes')
        .then(response => response.json())
        .then(Recettes => {
// Parcourir chaque élément de la liste Recettes
            for (let i = 0; i < Recettes.length; i++) {
                // Si la journée correspond à celle choisie
                if (Recettes[i].jour === jourChoisi)
                {
                    // Parcourir chaque repas de la journée
                    for (let j = 0; j < Recettes[i].meal.length; j++)
                    {
                        // Afficher le nom et la description du repas
                        let nomRepas = Recettes[i].meal[j].name;
                        let descRepas = Recettes[i].meal[j].description;

                        $("#carteRecette").append(
                            `<div class="card mb-3" style="max-width: 540px;">
          <div class="row g-0">
            <div class="col-md-4">
              <img src="${Recettes[i].meal[j].image}" class="img-fluid rounded-start" alt="...">
            </div>
            <div class="col-md-8">
              <div class="card-body">
                <h5 class="card-title">${nomRepas}</h5>
                <p class="card-text">${descRepas}</p>
                <p class="card-text"><small class="text-body-secondary">pour plus de détails</small></p>
              </div>
            </div>
          </div>
        </div>
        //si l'utilisateur est connecté il peut ajouter,supprimer,modifier des plats dans le planning
      <div class="card">
        <div class="card-body">
          <form>
            <input type ="text" id="meal" placeholder="Ajouter une recette">
            <input type="text" id="desc" placeholder="Ajouter une description">
            <input type="url" id="url" placeholder="Ajouter url de la recette">
            <input type="button"  class="btn btn-primary" value="Ajouter des plats" onclick="ajouterPlat()">
            <input type="button"  class="btn btn-primary" value="Suprimer ton plat" onclick="supprimerPlat()">
            <input type="button" class="btn btn-primary"  value="Modifier ton plat" onclick="modifierPlat()">
          </form>
        </div>
      </div>
`
                        );
                    }
                }
            }

        });

    return true;
    }
//ajouter des plats dans le planning
function ajouterPlat() {

    //POST : Envoyer des données au serveur JSON
    // creer de l'obejt
    const nouvelObjet=
        {
            "meal": [ { "name": "$plat1", "$description": "$description1",
                "image": "$https://images.unsplash.com/photo-1589989369979-8b1b2f1b1f1a?ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8cGxhdCUyMHBsYXR8ZW58MHx8MHx8&ixlib=rb-1.2.1&w=1000&q=80" }
        ]};
    // ajouter mon objet dans le server
    $.ajax('https://6427c806161067a83b00e7a8.mockapi.io/Recettes', {
        data : JSON.stringify(nouvelObjet),
        contentType : 'application/json',
        type : 'POST'
});
}
//supprimer des plats dans le planning
function supprimerPlat() {
    //DELETE : Supprimer des données du serveur
    $.ajax('https://6427c806161067a83b00e7a8.mockapi.io/Recettes', {
        type : 'DELETE'
    });
}
//modifier des plats dans le planning
function modifierPlat() {
    //PUT : Modifier des données du serveur
    $.ajax('https://6427c806161067a83b00e7a8.mockapi.io/Recettes', {
        type : 'PUT'
    });
}